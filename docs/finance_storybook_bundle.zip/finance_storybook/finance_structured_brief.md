# Finance Management & Monitoring System v1
## Structured Brief

### Source Basis
This brief is derived directly from the master specification provided in the conversation.
No external sources were used.

---

## 1. Brief Purpose
This document compresses the master blueprint into a build-oriented brief.
It separates the product into distinct modules, keeps the v1 operating model visible, and gives each module a short operational purpose.
It is intentionally shorter than the full blueprint and should be used as a working reference for planning, UI implementation, Storybook coverage, and team alignment.

---

## 2. Product Spine
The product has four clearly different layers.

### A. Monitoring Shell
Used to observe financial execution, detect problems, and route the user to the correct worklist.

### B. Revenue Core
Used to turn billable work into invoices, track receivables, and manage collection follow-up.

### C. Spend Core
Used to manage requests, approvals, supplier bills, and payment execution readiness.

### D. Supporting Control Layer
Used for budget control, auditability, and employee cost visibility.

---

## 3. Build Discipline
The system follows a strict navigation pattern:

`Overview -> Worklist -> Detail -> Action -> Back`

This matters because each screen should serve one operational role only.
The overview monitors.
Worklists triage.
Detail pages hold the single-record truth.
Action states should update the list context immediately after completion.

---

## 4. Basic Module Map

## 4.1 Monitoring Shell

### 1. Finance Overview Dashboard
**Purpose:** Show financial exposure and route the user to the correct operational worklist.

**Module role:** Monitoring shell.

**What it does:**
- Shows KPIs, trends, overdue signals, exposure, and budget pressure.
- Does not act as an execution screen.
- Every widget must drill down to a deterministic target.

**Primary outputs:**
- Revenue drilldowns
- Spend drilldowns
- Control drilldowns

---

## 4.2 Revenue Core

### 2. Invoice Drafts List
**Purpose:** Make invoice drafts visible, recoverable, and safe to manage.

**Module role:** Draft management worklist.

**What it does:**
- Surfaces stale drafts.
- Shows reserved lines.
- Prevents hidden draft locks.
- Routes users back into the draft builder.

### 3. Invoice Draft Builder
**Purpose:** Build an invoice draft from billable work without duplicate invoicing.

**Module role:** Draft composition workspace.

**What it does:**
- Separates source billable entries from selected draft lines.
- Prevents already invoiced or reserved entries from being reused.
- Shows totals, terms, and notes before issue/review.

### 4. Invoices List
**Purpose:** Provide an operational ledger of issued receivables.

**Module role:** Revenue worklist.

**What it does:**
- Supports search, filtering, overdue triage, and navigation to detail.
- Keeps payment status separate from fiscal/transmission status.

### 5. Invoice Detail View
**Purpose:** Provide the single-record truth for an issued receivable.

**Module role:** Revenue detail view.

**What it does:**
- Shows invoice summary, linked work, payments, collections history, and timeline.
- Makes outstanding amount and payment allocation visible.
- Supports collection-oriented review.

### 6. Collections / Receivables View
**Purpose:** Organize collection follow-up work by risk and urgency.

**Module role:** Collections worklist.

**What it does:**
- Prioritizes overdue receivables.
- Shows owner, expected payment date, and note snippet.
- Supports quick follow-up behavior.

---

## 4.3 Spend Core

### 7. Purchase Requests List
**Purpose:** Triage spend requests before approval and commitment.

**Module role:** Spend intake worklist.

**What it does:**
- Shows request status, urgency, approver, budget signal, and attachments.
- Routes the user into approval detail.

### 8. Purchase Request Detail / Approval View
**Purpose:** Support a documented approval or rejection decision.

**Module role:** Approval detail workspace.

**What it does:**
- Shows justification, attachments, supplier context, and budget impact.
- Makes the decision traceable.
- Supports approve, reject, or request changes.

### 9. Supplier Bills / Expenses List
**Purpose:** Show payables readiness and surface blocked supplier bills.

**Module role:** Payables worklist.

**What it does:**
- Separates ready items from blocked or mismatched items.
- Shows open payables, due context, readiness, and link-to-request status.

### 10. Supplier Bill Detail View
**Purpose:** Explain why a supplier bill is ready or blocked for payment.

**Module role:** Payables detail view.

**What it does:**
- Shows discrepancy evidence.
- Makes missing data or mismatch actionable.
- Supports resolution and handoff to payments.

### 11. Payments Queue
**Purpose:** Execute or hand off ready payables while keeping blockers visible.

**Module role:** Payment execution worklist.

**What it does:**
- Separates ready, blocked, due soon, and overdue items.
- Supports selection, scheduling, and execution states.
- Must not imply that selection alone changes lifecycle state.

---

## 4.4 Supporting Control Layer

### 12. Budget Overview
**Purpose:** Show budget pressure, variance, and remaining capacity.

**Module role:** Budget control surface.

**What it does:**
- Shows budgeted, committed, actual paid, remaining, and variance.
- Supports drilldown into the drivers of pressure.
- Does not become forecasting or accounting in v1.

### 13. Audit Trail / Activity Log
**Purpose:** Provide traceability for actions across finance modules.

**Module role:** Evidence layer.

**What it does:**
- Shows who changed what, when, and where.
- Supports before/after visibility where available.
- Routes users to the target record.

### 14. Employee Cost View
**Purpose:** Show operational employee cost visibility with role-based restrictions.

**Module role:** Cost insight surface.

**What it does:**
- Shows cost concentration, billable split, and allocation insight.
- Supports aggregate-only visibility for restricted roles.

---

## 5. Module Classification Table

| Module | Layer | Operational Role | One-line purpose |
|---|---|---|---|
| Finance Overview Dashboard | Monitoring | Monitoring shell | Detect issues and route the user to the right worklist |
| Invoice Drafts List | Revenue | Worklist | Surface and recover invoice drafts safely |
| Invoice Draft Builder | Revenue | Workspace | Turn billable work into invoice drafts safely |
| Invoices List | Revenue | Worklist | Triage issued receivables |
| Invoice Detail View | Revenue | Detail | Show full truth for one receivable |
| Collections / Receivables View | Revenue | Worklist | Run follow-up on open receivables |
| Purchase Requests List | Spend | Worklist | Triage requests before commitment |
| Purchase Request Detail / Approval View | Spend | Detail | Approve, reject, or request changes with context |
| Supplier Bills / Expenses List | Spend | Worklist | Triage payables by readiness |
| Supplier Bill Detail View | Spend | Detail | Resolve mismatch and payment blockers |
| Payments Queue | Spend | Worklist | Execute or hand off ready payments |
| Budget Overview | Control | Control surface | Monitor budget pressure and variance |
| Audit Trail / Activity Log | Control | Evidence layer | Trace actions across records and modules |
| Employee Cost View | Control | Insight surface | Expose employee cost signals within permissions |

---

## 6. Minimum Screen Purpose Rules
Each module should pass the following test.

### Finance Overview Dashboard
Shows what needs attention.

### Worklists
Show what the user should process next.

### Detail views
Show why this record is in its current state.

### Control screens
Show pressure, traceability, or visibility constraints.

If a screen tries to monitor, triage, edit deeply, and audit at the same time, it is doing too much.
That is where systems become swamp instead of workflow.

---

## 7. Canonical v1 Rules That Must Stay Stable in UI
These are the short build rules that should not drift during implementation.

### Payment and paid-state safety
- Paid must derive from allocated payment amount covering the outstanding balance.
- A payment record alone does not mean the record is paid.
- Outstanding amount must remain visible.
- Unallocated remainder must be shown explicitly.

### Readiness safety
- Unlinked supplier bills are warning-level and blocked by default in v1.
- Missing due date or missing critical attachment can block payment.
- Ready and blocked must stay visually separate.

### Date semantics safety
- Cash metrics use payment date.
- Invoicing metrics use issue date.
- Commitment metrics use approval date.
- Overdue and aging use due date versus today.

### State semantics safety
UI must distinguish:
- persisted domain status,
- operational signal,
- UI-only flag,
- temporary selection state.

That separation is not cosmetic. It prevents fake meaning from leaking into the system.

---

## 8. Suggested Storybook Coverage Strategy
Storybook for this system should cover two levels.

### A. Shared UI primitives
Use stories for the reusable interaction vocabulary:
- status chips
- KPI cards
- filter bar
- worklist table
- side detail panel
- warning / blocked banners
- empty states
- timeline items

### B. Module blueprint stories
Use one base story per module to verify:
- screen purpose
- layout regions
- visible fields
- state treatment
- empty / warning / blocked variants

This is the fastest way to align product, design, and implementation before real API data exists.

---

## 9. Suggested Folder Structure

```text
storybook/
  finance/
    shared/
      finance-shared-primitives.stories.tsx
    screens/
      finance-screen-blueprints.stories.tsx
```

If the team later has real components, split the stories by module:

```text
src/
  modules/
    finance/
      overview/
        OverviewDashboard.tsx
        OverviewDashboard.stories.tsx
      revenue/
        InvoiceDraftsList.tsx
        InvoiceDraftsList.stories.tsx
        InvoiceDraftBuilder.tsx
        InvoiceDraftBuilder.stories.tsx
        InvoicesList.tsx
        InvoicesList.stories.tsx
        InvoiceDetailView.tsx
        InvoiceDetailView.stories.tsx
        CollectionsView.tsx
        CollectionsView.stories.tsx
      spend/
        PurchaseRequestsList.tsx
        PurchaseRequestsList.stories.tsx
        PurchaseRequestDetailView.tsx
        PurchaseRequestDetailView.stories.tsx
        SupplierBillsList.tsx
        SupplierBillsList.stories.tsx
        SupplierBillDetailView.tsx
        SupplierBillDetailView.stories.tsx
        PaymentsQueue.tsx
        PaymentsQueue.stories.tsx
      control/
        BudgetOverview.tsx
        BudgetOverview.stories.tsx
        AuditTrailView.tsx
        AuditTrailView.stories.tsx
        EmployeeCostView.tsx
        EmployeeCostView.stories.tsx
```

---

## 10. Recommended First Storybook Milestone
The first milestone should not try to simulate the whole system.
It should prove the screen roles and the common UI language.

### Phase 1
Build stories for:
- Finance Overview Dashboard
- Invoice Drafts List
- Invoice Draft Builder
- Invoices List
- Collections / Receivables View
- Supplier Bills / Expenses List
- Payments Queue
- Budget Overview

### Why these first
These eight screens cover the spine of the system:
monitoring, revenue triage, spend triage, execution readiness, and control pressure.
If these are coherent, the rest becomes much easier to implement without contradictions.

---

## 11. Final Build Note
The correct simplification is not “fewer screens at all costs”.
The correct simplification is “one screen, one job”.
That is the real difference between a UI that helps operations and a UI that slowly poisons them.
